import React from 'react'

const AdminPage: React.FC = () => {
    return (
        <div>
            <h1>AdminPage</h1>
        </div>
    )
}

export default AdminPage