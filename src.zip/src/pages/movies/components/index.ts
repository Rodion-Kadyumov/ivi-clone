export { default as Card } from './Card'
export { default as CategoryMovies } from './CategoryMovies'