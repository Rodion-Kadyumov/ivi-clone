import React from 'react'

const ErrorPage: React.FC = () => {
    return (
        <div>
            <h1>ErrorPage</h1>
        </div>
    )
}

export default ErrorPage