export { default as PersonMainSection } from './PersonMainSection'
export { default as PersonFilmography } from './person-filmography/index'